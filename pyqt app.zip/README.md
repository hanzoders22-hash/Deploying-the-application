# PyQt App Shell — Build-ready project (Coursework)

This repository contains a minimal, ready-to-build PyQt6 application scaffold and instructions to produce executable artifacts.

## Contents
- `main.py` — main application (PyQt6). Run with `python main.py`.
- `requirements.txt` — Python dependencies.
- `build_exe.sh` — example script using PyInstaller to build a standalone executable.
- `design_document.md` — short design document required by the assignment.

## Run (development)
1. Create virtual environment (recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate   # Linux / macOS
   venv\Scripts\activate    # Windows (PowerShell)
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the app:
   ```bash
   python main.py
   ```

## Build executable (example with PyInstaller)
This creates a single-file executable (may be large). Tested workflow (adjust for your OS).

1. Install PyInstaller (already in `requirements.txt`):
   ```bash
   pip install pyinstaller
   ```
2. Build (one-file, windowed):
   ```bash
   pyinstaller --noconfirm --onefile --windowed --name PyQtApp main.py
   ```
3. Result (on success):
   - Windows: `dist\PyQtApp.exe`
   - Linux/macOS: `dist/PyQtApp`

## Extra notes for graders
- If packaging for Windows on Linux/macOS you may need to build on Windows (cross-building not officially supported).
- If additional assets or modules are added, update the spec file or add them with `--add-data` flags.

## What to submit
Upload the produced `exe` (or binary) and the `dist/` folder, or upload the `pyqt_app.zip` archive that contains project sources and README. Include build logs if any problems occur.

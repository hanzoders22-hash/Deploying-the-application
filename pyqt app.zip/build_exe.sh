#!/bin/bash
# Example build script for Linux/macOS (adjust on Windows)
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
pyinstaller --noconfirm --onefile --windowed --name PyQtApp main.py
echo "Build finished. Check dist/ directory."

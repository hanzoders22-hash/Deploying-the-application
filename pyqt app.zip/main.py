# Simple PyQt6 application shell
# Run: python main.py
from PyQt6.QtWidgets import (QApplication, QMainWindow, QLabel, QPushButton,
                             QVBoxLayout, QWidget, QFileDialog, QMessageBox, QLineEdit, QTextEdit)
from PyQt6.QtCore import Qt
import sys, os

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PyQt App Shell — Sales Manager Remote Workspace")
        self.resize(800, 520)
        central = QWidget()
        self.setCentralWidget(central)

        self.status = self.statusBar()
        self.status.showMessage("Ready")

        layout = QVBoxLayout()
        self.label = QLabel("Welcome! This is a ready-to-build PyQt application shell.")
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.label)

        self.input = QLineEdit()
        self.input.setPlaceholderText("Type something here...")
        layout.addWidget(self.input)

        self.text = QTextEdit()
        self.text.setPlaceholderText("Project notes or logs will appear here.")
        layout.addWidget(self.text, 1)

        btn_save = QPushButton("Save notes to file")
        btn_save.clicked.connect(self.save_notes)
        layout.addWidget(btn_save)

        btn_open = QPushButton("Open text file")
        btn_open.clicked.connect(self.open_file)
        layout.addWidget(btn_open)

        btn_about = QPushButton("About")
        btn_about.clicked.connect(self.about)
        layout.addWidget(btn_about)

        central.setLayout(layout)

    def save_notes(self):
        fname, _ = QFileDialog.getSaveFileName(self, "Save notes", os.path.expanduser("~"), "Text files (*.txt);;All files (*)")
        if fname:
            try:
                with open(fname, "w", encoding="utf-8") as f:
                    f.write(self.text.toPlainText())
                self.status.showMessage(f"Saved: {fname}", 5000)
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))

    def open_file(self):
        fname, _ = QFileDialog.getOpenFileName(self, "Open text file", os.path.expanduser("~"), "Text files (*.txt);;All files (*)")
        if fname:
            try:
                with open(fname, "r", encoding="utf-8") as f:
                    self.text.setPlainText(f.read())
                self.status.showMessage(f"Opened: {fname}", 5000)
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))

    def about(self):
        QMessageBox.information(self, "About", "PyQt App Shell\n\nCreated for coursework: build-ready project scaffold.\nAuthor: Student")

def main():
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec())

if __name__ == '__main__':
    main()

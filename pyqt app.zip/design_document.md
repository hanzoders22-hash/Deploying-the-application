# Design Document — PyQt App Shell

**Project purpose**: Provide a small GUI shell for a "Sales Manager Remote Workspace" app that can be extended later. The goal for the coursework is to provide a complete, buildable project and clear instructions for the grader to run or create an executable.

## High-level architecture
- Single-window PyQt6 application.
- Components:
  - MainWindow (QMainWindow) — contains status bar, central widget.
  - Central widget — QVBoxLayout with QLabel, QLineEdit, QTextEdit and control buttons.
  - File operations use QFileDialog.

## Build / Dependencies
- Python 3.9+ recommended.
- PyQt6 for GUI layer.
- PyInstaller for bundling to a single executable.

## Required steps to reproduce
1. Create and activate virtual environment.
2. `pip install -r requirements.txt`
3. `python main.py` to run
4. Optionally: build with PyInstaller using provided script or command in README.

## Tests / Verification
- Run `python main.py` and verify window opens and buttons function:
  - Type text in the editor and use "Save notes to file" to confirm file writing.
  - Use "Open text file" to confirm file reading.
  - Press "About" to confirm modal works.

## Known limitations
- Icon assets not included (optional).
- For Windows executable, build on Windows to avoid dependency issues.

## Extension ideas
- Add network sync to remote server.
- Add user authentication and settings persistence.
- Add packaging for different platforms with CI (GitHub Actions).
